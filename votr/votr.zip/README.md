#Votr - a realtime SMS voting application built on Node & CouchDB

## Requirements

* Node server
* CouchDB server

## Installation

```
git clone https://code.hq.twilio.com/devangels/votr
cd votr
npm install
mv config-sample.js config.js
```

Edit the config.js to include information about your:
* CouchDB instance (I recommend using a hosted solution like [Cloudant](http://cloudant.com))
* Twilio account

Now you're ready to run the app. You can spin up the server locally with `node .` and use Ngrok to get your app on the public internet or you can deploy the app to a hosted environment (I recommend [Nodejitsu](http://nodejitsu.com)). 

If this is the first time you're running the app and your CouchDB is empty, the app will go ahead and insert a design doc. You don't need to worry about this and it won't happen on subsequent startups.

Log-in to your Twilio account and set the `Voice Request URL` and `Messaging Request URL` to point at your Node server with the relative paths of `/vote/voice` and `/vote/sms` respectively.

## Setting Up an Event

Now you're ready to create a "voting event". Open up your browser and go to `http://nodeserver/admin`. This should display a log-in screen. Your credentials are the same as your CouchDB credentials. Once you've logged-in, click the "Create New Event" button. When you're filling in the fields, please follow these guidlines:
* Keep the `short name` URL friendly. Your event page will be located at `http://nodeserver/events/{short name}`
* Format the phone number as [E.164](http://en.wikipedia.org/wiki/E.164)
* State of voting (on or off)

Click "Save" when you're done.

## Voting!

Now you're ready to do some voting! This works most effectively if you are projecting the voting results page because it updates in real-time as votes come in. Just navigate to `http://nodeserver/events/{short name}`.

Each person is only allowed to vote once. No stuffing the ballot box.

## Questions?

Ping carter@twilio.com









